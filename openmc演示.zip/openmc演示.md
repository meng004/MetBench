

OpenMC软件测试平台DevOps演示

https://pcn6l3u1ti8n.feishu.cn/wiki/D6ZSwSJiKiGNFikrNyrcvMgWn2c#B6egdrNaQoJRu5xZeYPcBIGynKc



需求：

并反馈软件缺陷，在缺陷修复后执行回归测试，形成完成的测试闭环。

测试管理功能需支持测试任务的创建、分解、跟踪、评审等需求，具备任务分配、流转过程的可视化能力，支持多人多任务协调管理。

以OpenMC软件作为演示案例：

1. OpenMC是用于反应堆物理计算的蒙特卡罗中子输运程序，这是一款开源程序，github地址如下：

   1.  https://github.com/openmc-dev/openmc

   

2. 官方的安装及使用指南如下：

   1.  https://docs.openmc.org/en/stable/quickinstall.html

   

3. 由网友分享的视频教程和中文安装教程如下：

   1.  【Openmc安装教程（蒙特卡洛中子和光子输运模拟软件）】
   2.   https://www.bilibili.com/video/BV1PjhfzvEHT/?share_source=copy_web&vd_source=86c8aa6ed92efc151cc222e2db6076af

openmc程序的编译与安装.pdf



   OpenMC安装教程中的数据库也可以用我这边下载好的，大小约1.54G：

​    链接:https://pan.baidu.com/s/15bOIllRwN1ZmdNYQKCo5vw?pwd=t5ae 

1. OpenMC在DevOps部署后的测试用例的官方链接：

   1.  https://github.com/openmc-dev/openmc/wiki/Example-Jupyter-Notebooks

   

2. 测试用例也可以用我这边的：

   1.  单栅元测试用例，此算例对计算机的算力要求极小，即使是个人pc也能在几分钟内算完：

   pincell.7z

